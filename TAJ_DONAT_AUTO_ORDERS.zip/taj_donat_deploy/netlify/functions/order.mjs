export default async (request) => {
  if (request.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405, headers: { 'content-type': 'application/json' } });
  }
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.ADMIN_CHAT_ID;
  if (!token || !chatId) {
    return new Response(JSON.stringify({ error: 'Server is not configured' }), { status: 500, headers: { 'content-type': 'application/json' } });
  }
  let data;
  try { data = await request.json(); } catch {
    return new Response(JSON.stringify({ error: 'Invalid JSON' }), { status: 400, headers: { 'content-type': 'application/json' } });
  }
  const uid = String(data.uid || '').trim();
  const nickname = String(data.nickname || '').trim().slice(0, 80) || 'не указан';
  const contact = String(data.contact || '').trim().slice(0, 120);
  const payment = String(data.payment || 'Не указан').slice(0, 80);
  const items = Array.isArray(data.items) ? data.items.slice(0, 10) : [];
  if (!/^\d{5,20}$/.test(uid) || !contact || !items.length) {
    return new Response(JSON.stringify({ error: 'Проверь UID, контакт и корзину' }), { status: 400, headers: { 'content-type': 'application/json' } });
  }
  const safe = (v) => String(v ?? '').replace(/[<>]/g, '').slice(0, 100);
  const itemLines = items.map((item) => `• ${safe(item.diamonds)} × ${Math.max(1, Math.min(99, Number(item.quantity) || 1))}`).join('\n');
  const message = `💎 НОВЫЙ ЗАКАЗ — TAJ DONAT\n\nUID: ${uid}\nНик: ${nickname}\nКонтакт: ${contact}\nОплата: ${payment}\n\nПакеты:\n${itemLines}\n\nСтатус: ожидает подтверждения продавца`;
  const tg = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ chat_id: chatId, text: message })
  });
  const result = await tg.json().catch(() => ({}));
  if (!tg.ok || !result.ok) {
    return new Response(JSON.stringify({ error: 'Telegram could not send the order' }), { status: 502, headers: { 'content-type': 'application/json' } });
  }
  return new Response(JSON.stringify({ ok: true }), { status: 200, headers: { 'content-type': 'application/json' } });
};
